var searchData=
[
  ['new_5fline_0',['new_line',['../file_8c.html#ab4a919c35969928cee64cea01bf682f6',1,'new_line():&#160;file.c'],['../settings_8h.html#ab4a919c35969928cee64cea01bf682f6',1,'new_line():&#160;file.c']]]
];
