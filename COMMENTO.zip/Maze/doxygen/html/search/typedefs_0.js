var searchData=
[
  ['coordinates_5ft_0',['coordinates_t',['../settings_8h.html#a99e6f99bd13791507eef5c6d85455023',1,'settings.h']]]
];
