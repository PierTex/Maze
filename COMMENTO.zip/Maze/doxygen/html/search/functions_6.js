var searchData=
[
  ['print_5fpath_0',['print_path',['../file_8c.html#a76ba80eeac2542ce87b6380ecdb61175',1,'print_path(path_t *path):&#160;file.c'],['../settings_8h.html#a76ba80eeac2542ce87b6380ecdb61175',1,'print_path(path_t *path):&#160;file.c']]],
  ['printmaze_1',['printMaze',['../file_8c.html#a85156ef5b96ace6c73b6379248eb5da3',1,'printMaze(char **maze, int x, int y):&#160;file.c'],['../settings_8h.html#a85156ef5b96ace6c73b6379248eb5da3',1,'printMaze(char **maze, int x, int y):&#160;file.c']]]
];
