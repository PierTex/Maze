var searchData=
[
  ['y_0',['y',['../structCoordinates.html#aae83211da8e94ae2edd3b407c19bff07',1,'Coordinates']]],
  ['yellow_1',['YELLOW',['../file_8c.html#abf681265909adf3d3e8116c93c0ba179',1,'file.c']]]
];
