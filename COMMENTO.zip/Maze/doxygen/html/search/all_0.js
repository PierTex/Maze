var searchData=
[
  ['add_5fmove_0',['add_move',['../file_8c.html#ae508aa3391d64bf913ca5b255f47e08e',1,'add_move(path_t *path, game_t *game):&#160;file.c'],['../settings_8h.html#ae508aa3391d64bf913ca5b255f47e08e',1,'add_move(path_t *path, game_t *game):&#160;file.c']]],
  ['ai_5frandom_1',['AI_random',['../main_8c.html#a646740897a9a3bc71db83103e54b1bea',1,'main.c']]],
  ['ai_5fright_5fhand_2',['AI_right_hand',['../main_8c.html#ae98a2a22dcff5e76d3a703fdb422407f',1,'main.c']]],
  ['automove_3',['automove',['../structGame.html#a0d1d830dab1e47d204f5f2b0037dc6f1',1,'Game']]]
];
