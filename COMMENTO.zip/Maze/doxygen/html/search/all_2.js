var searchData=
[
  ['capacity_0',['capacity',['../structPath.html#acb0deb3d53490424070c45d2c843eaa0',1,'Path']]],
  ['cell_5f1_1',['cell_1',['../structNeighbors.html#a53a86ddb0c3f71c43db1161bac0ee61d',1,'Neighbors']]],
  ['cell_5f2_2',['cell_2',['../structNeighbors.html#ab8856e5c736ce432e5a87a0d91ebc60b',1,'Neighbors']]],
  ['cell_5f3_3',['cell_3',['../structNeighbors.html#a222cfe3b8a1acd3671397211c3e55dc8',1,'Neighbors']]],
  ['check_5fcollectable_4',['check_collectable',['../file_8c.html#a50fb37f61aa4ce51e6db89b3f3863234',1,'check_collectable(char **maze, game_t *game):&#160;file.c'],['../settings_8h.html#a50fb37f61aa4ce51e6db89b3f3863234',1,'check_collectable(char **maze, game_t *game):&#160;file.c']]],
  ['check_5fnear_5fcells_5fe_5',['check_near_cells_E',['../file_8c.html#aca1735f9c6420d4901227d6057c57fda',1,'check_near_cells_E(char **maze, int x, int y, int *odds, neighbors_t cells, game_t *game):&#160;file.c'],['../settings_8h.html#a59da9c075ff446e712e222778309f2b9',1,'check_near_cells_E(char **maze, int x, int y, int *cell, neighbors_t cells, game_t *game):&#160;file.c']]],
  ['check_5fnear_5fcells_5fn_6',['check_near_cells_N',['../file_8c.html#a6a6a299194d8be81eb46bd877dbc3c4d',1,'check_near_cells_N(char **maze, int y, int *odds, neighbors_t cells, game_t *game):&#160;file.c'],['../settings_8h.html#a9a2128b23b541fcce0c9519e0565bcfc',1,'check_near_cells_N(char **maze, int y, int *cell, neighbors_t cells, game_t *game):&#160;file.c']]],
  ['check_5fnear_5fcells_5fo_7',['check_near_cells_O',['../settings_8h.html#a151ce0b622da002bc02016f793accc32',1,'check_near_cells_O(char **maze, int y, int *cell, neighbors_t cells, game_t *game):&#160;file.c'],['../file_8c.html#aa05397fd861394f6f93dd8d3374631f0',1,'check_near_cells_O(char **maze, int x, int *odds, neighbors_t cells, game_t *game):&#160;file.c']]],
  ['check_5fnear_5fcells_5fs_8',['check_near_cells_S',['../settings_8h.html#a66421a00935ac1d2d995276385f7f57e',1,'check_near_cells_S(char **maze, int x, int y, int *cell, neighbors_t cells, game_t *game):&#160;file.c'],['../file_8c.html#a00ab2afc8353ad0bbcf1d09e265691f2',1,'check_near_cells_S(char **maze, int x, int y, int *odds, neighbors_t cells, game_t *game):&#160;file.c']]],
  ['checkdigitdirection_9',['checkDigitDirection',['../file_8c.html#a45b01cf694150330b9d7735492e3c1cb',1,'checkDigitDirection(char direction):&#160;file.c'],['../settings_8h.html#a45b01cf694150330b9d7735492e3c1cb',1,'checkDigitDirection(char direction):&#160;file.c']]],
  ['checkfinish_10',['checkFinish',['../file_8c.html#ac111206b1460836f4fa03249f09ad8ec',1,'checkFinish(game_t *game):&#160;file.c'],['../settings_8h.html#ac111206b1460836f4fa03249f09ad8ec',1,'checkFinish(game_t *game):&#160;file.c']]],
  ['coins_11',['coins',['../structGame.html#abf61f1b5aaa1ff1687c20dced13fa0ae',1,'Game']]],
  ['color_5freset_12',['COLOR_RESET',['../file_8c.html#a17f760256046df23dd0ab46602f04d02',1,'file.c']]],
  ['coordinates_13',['Coordinates',['../structCoordinates.html',1,'']]],
  ['coordinates_5ft_14',['coordinates_t',['../settings_8h.html#a99e6f99bd13791507eef5c6d85455023',1,'settings.h']]],
  ['copy_5fmatrix_15',['copy_matrix',['../file_8c.html#a302cabf420f230abdddc9b2c6f1d33df',1,'copy_matrix(int x, int y, char **maze_to, char **maze_from, game_t *game):&#160;file.c'],['../settings_8h.html#a302cabf420f230abdddc9b2c6f1d33df',1,'copy_matrix(int x, int y, char **maze_to, char **maze_from, game_t *game):&#160;file.c']]],
  ['create_5fbody_16',['create_body',['../file_8c.html#abb820848d3c2d0810711fcbb8d827401',1,'create_body():&#160;file.c'],['../settings_8h.html#abb820848d3c2d0810711fcbb8d827401',1,'create_body():&#160;file.c']]],
  ['create_5fsnake_5fhead_17',['create_snake_head',['../file_8c.html#a427b4b2e2812602b445c38e5c045157a',1,'create_snake_head(game_t *game):&#160;file.c'],['../settings_8h.html#a427b4b2e2812602b445c38e5c045157a',1,'create_snake_head(game_t *game):&#160;file.c']]],
  ['createmaze_18',['createMaze',['../file_8c.html#a02928035c96cc0dd941f21c4e48131a5',1,'createMaze(int x, int y, game_t *game):&#160;file.c'],['../settings_8h.html#a02928035c96cc0dd941f21c4e48131a5',1,'createMaze(int x, int y, game_t *game):&#160;file.c']]],
  ['current_19',['current',['../structScore.html#a640ba9daa684f85b468296a1e76ee279',1,'Score']]],
  ['cyan_20',['CYAN',['../file_8c.html#ad243f93c16bc4c1d3e0a13b84421d760',1,'file.c']]]
];
