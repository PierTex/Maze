var searchData=
[
  ['size_0',['size',['../structPath.html#ae355e23fe8b1b2b3dc8864ffe49c7652',1,'Path']]],
  ['snake_5fhead_1',['snake_head',['../structGame.html#ae67a6ba232c14653ac6f86824b6217a2',1,'Game']]],
  ['steps_2',['steps',['../structGame.html#a8ced659ba837811536c26ccd17ded578',1,'Game']]]
];
