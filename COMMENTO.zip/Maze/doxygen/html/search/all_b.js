var searchData=
[
  ['neighbors_0',['Neighbors',['../structNeighbors.html',1,'']]],
  ['neighbors_5ft_1',['neighbors_t',['../settings_8h.html#a6e85e051baeb4518fdf31af924362943',1,'settings.h']]],
  ['new_5fline_2',['new_line',['../file_8c.html#ab4a919c35969928cee64cea01bf682f6',1,'new_line():&#160;file.c'],['../settings_8h.html#ab4a919c35969928cee64cea01bf682f6',1,'new_line():&#160;file.c']]],
  ['next_3',['next',['../structNode.html#af67b110ca1a258b793bf69d306929b22',1,'Node']]],
  ['node_4',['Node',['../structNode.html',1,'']]]
];
