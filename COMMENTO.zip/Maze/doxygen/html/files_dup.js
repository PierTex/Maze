var files_dup =
[
    [ "file.c", "file_8c.html", "file_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "settings.h", "settings_8h.html", "settings_8h" ]
];