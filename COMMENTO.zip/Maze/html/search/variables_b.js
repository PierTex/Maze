var searchData=
[
  ['x_0',['x',['../structCoordinates.html#a11c878fbd2d0805c91af17d2ba2289a1',1,'Coordinates']]]
];
