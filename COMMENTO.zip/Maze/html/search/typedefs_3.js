var searchData=
[
  ['neighbors_5ft_0',['neighbors_t',['../settings_8h.html#a6e85e051baeb4518fdf31af924362943',1,'settings.h']]]
];
