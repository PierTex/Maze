var structGame =
[
    [ "automove", "structGame.html#a0d1d830dab1e47d204f5f2b0037dc6f1", null ],
    [ "backup", "structGame.html#afc651ab7bc7ff2ae0a9d3b705f447d90", null ],
    [ "coins", "structGame.html#abf61f1b5aaa1ff1687c20dced13fa0ae", null ],
    [ "drills", "structGame.html#a9dec5f16b1ecfdd65b5f392992bcedf6", null ],
    [ "ending", "structGame.html#aa7f08b87353bb5f9a6991aad8e813689", null ],
    [ "entrance", "structGame.html#ae9766d64be3c74ca5183c23213823e13", null ],
    [ "final_score", "structGame.html#ae6d742b7696fcc33598a4bfb42fec0c0", null ],
    [ "head", "structGame.html#a5247050a1f72e586eb4b6d30257f5cce", null ],
    [ "maze_size", "structGame.html#a57e8ed079a8339404208e48434671171", null ],
    [ "penalties", "structGame.html#ae7429f0d4b98778c7f87f3f2471459a1", null ],
    [ "snake_head", "structGame.html#ae67a6ba232c14653ac6f86824b6217a2", null ],
    [ "steps", "structGame.html#a8ced659ba837811536c26ccd17ded578", null ]
];