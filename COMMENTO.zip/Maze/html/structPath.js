var structPath =
[
    [ "capacity", "structPath.html#acb0deb3d53490424070c45d2c843eaa0", null ],
    [ "moves", "structPath.html#a9b9ce3379439b175cbb8b88ab4a69c31", null ],
    [ "size", "structPath.html#ae355e23fe8b1b2b3dc8864ffe49c7652", null ]
];