Nome gruppo "Commento"
Deppieri Luca,    mat. 881996
Tesser Pierpaolo, mat. 887438
Zambon Walter,    mat. 887438