var annotated_dup =
[
    [ "Coordinates", "structCoordinates.html", "structCoordinates" ],
    [ "Game", "structGame.html", "structGame" ],
    [ "Neighbors", "structNeighbors.html", "structNeighbors" ],
    [ "Node", "structNode.html", "structNode" ],
    [ "Path", "structPath.html", "structPath" ],
    [ "Score", "structScore.html", "structScore" ]
];