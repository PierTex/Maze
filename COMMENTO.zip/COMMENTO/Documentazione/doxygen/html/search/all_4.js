var searchData=
[
  ['ending_0',['ending',['../structGame.html#aa7f08b87353bb5f9a6991aad8e813689',1,'Game']]],
  ['entrance_1',['entrance',['../structGame.html#ae9766d64be3c74ca5183c23213823e13',1,'Game']]]
];
