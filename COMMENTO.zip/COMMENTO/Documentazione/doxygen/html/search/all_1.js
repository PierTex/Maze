var searchData=
[
  ['backup_0',['backup',['../structGame.html#afc651ab7bc7ff2ae0a9d3b705f447d90',1,'Game']]],
  ['best_1',['best',['../structScore.html#abcf246d1a7cfd156d8c9c1fa85433116',1,'Score']]],
  ['body_2',['body',['../structNode.html#aa4a9a7abf6362e3646d43814e69434f9',1,'Node']]],
  ['brown_5fburlywood_3',['BROWN_BURLYWOOD',['../file_8c.html#adfa483b836f52df48f183e600132b423',1,'file.c']]]
];
