var searchData=
[
  ['init_5fpath_0',['init_path',['../file_8c.html#ac042d0ce553a2bce6703554d9f2d2deb',1,'init_path(path_t *path, game_t *game):&#160;file.c'],['../settings_8h.html#ac042d0ce553a2bce6703554d9f2d2deb',1,'init_path(path_t *path, game_t *game):&#160;file.c']]],
  ['inputfile_1',['inputFile',['../file_8c.html#a740a49fb9a9623944c24c8db11f89e8e',1,'inputFile(int M, int N):&#160;file.c'],['../settings_8h.html#a740a49fb9a9623944c24c8db11f89e8e',1,'inputFile(int M, int N):&#160;file.c']]],
  ['insertmove_2',['insertMove',['../file_8c.html#a66ce33d01614d09be1b18296b177dce3',1,'insertMove(game_t *game):&#160;file.c'],['../settings_8h.html#a66ce33d01614d09be1b18296b177dce3',1,'insertMove(game_t *game):&#160;file.c']]],
  ['interactive_3',['interactive',['../main_8c.html#a5e4ccfd2baa2769487f3de56cc82f400',1,'main.c']]]
];
