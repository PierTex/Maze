var searchData=
[
  ['refresh_0',['refresh',['../file_8c.html#a5f2e190b8261a98c97c2ea4e86670d54',1,'refresh():&#160;file.c'],['../settings_8h.html#a5f2e190b8261a98c97c2ea4e86670d54',1,'refresh():&#160;file.c']]]
];
