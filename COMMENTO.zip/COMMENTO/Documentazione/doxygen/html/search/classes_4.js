var searchData=
[
  ['score_0',['Score',['../structScore.html',1,'']]]
];
