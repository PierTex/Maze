var searchData=
[
  ['final_5fscore_0',['final_score',['../structGame.html#ae6d742b7696fcc33598a4bfb42fec0c0',1,'Game']]]
];
