var searchData=
[
  ['init_5fcapacity_0',['INIT_CAPACITY',['../file_8c.html#a1c2454dbbfd298b8e2cd09eb93b6a8f6',1,'file.c']]]
];
