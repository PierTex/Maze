var searchData=
[
  ['coordinates_0',['Coordinates',['../structCoordinates.html',1,'']]]
];
