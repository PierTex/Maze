var searchData=
[
  ['color_5freset_0',['COLOR_RESET',['../file_8c.html#a17f760256046df23dd0ab46602f04d02',1,'file.c']]],
  ['cyan_1',['CYAN',['../file_8c.html#ad243f93c16bc4c1d3e0a13b84421d760',1,'file.c']]]
];
