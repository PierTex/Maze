var searchData=
[
  ['game_5ft_0',['game_t',['../settings_8h.html#a9c0832eaec097b981c4b4cffce08ce29',1,'settings.h']]]
];
