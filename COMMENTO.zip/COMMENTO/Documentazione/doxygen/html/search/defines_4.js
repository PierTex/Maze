var searchData=
[
  ['red_5fcrimson_0',['RED_CRIMSON',['../file_8c.html#a43d2f00e8028dd24854b0a4d7844ea91',1,'file.c']]]
];
