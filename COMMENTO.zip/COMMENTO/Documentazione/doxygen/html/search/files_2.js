var searchData=
[
  ['settings_2eh_0',['settings.h',['../settings_8h.html',1,'']]]
];
