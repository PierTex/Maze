var searchData=
[
  ['path_5ft_0',['path_t',['../settings_8h.html#a613b3eb48b932fd2d0264bbe8555779b',1,'settings.h']]]
];
