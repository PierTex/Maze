var searchData=
[
  ['penalties_0',['penalties',['../structGame.html#ae7429f0d4b98778c7f87f3f2471459a1',1,'Game']]]
];
