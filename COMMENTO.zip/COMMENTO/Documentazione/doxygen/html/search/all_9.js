var searchData=
[
  ['list_5ft_0',['list_t',['../settings_8h.html#aa70e0d34d8118aa7d683da35e39db0c1',1,'settings.h']]]
];
