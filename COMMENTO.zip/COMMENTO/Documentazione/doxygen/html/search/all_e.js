var searchData=
[
  ['score_0',['score',['../file_8c.html#a19a950c8aa15a517720ea670b32cabde',1,'score(game_t *game):&#160;file.c'],['../settings_8h.html#a19a950c8aa15a517720ea670b32cabde',1,'score(game_t *game):&#160;file.c']]],
  ['score_1',['Score',['../structScore.html',1,'']]],
  ['score_5ft_2',['score_t',['../settings_8h.html#a1aa2f17f03b90cd6716cc003eab4a93d',1,'settings.h']]],
  ['settings_2eh_3',['settings.h',['../settings_8h.html',1,'']]],
  ['size_4',['size',['../structPath.html#ae355e23fe8b1b2b3dc8864ffe49c7652',1,'Path']]],
  ['snake_5fhead_5',['snake_head',['../structGame.html#ae67a6ba232c14653ac6f86824b6217a2',1,'Game']]],
  ['snakeappend_6',['snakeAppend',['../file_8c.html#a50a115249471a97471cfa887e5651feb',1,'snakeAppend(list_t *new_body, int x, int y, game_t *game):&#160;file.c'],['../settings_8h.html#a50a115249471a97471cfa887e5651feb',1,'snakeAppend(list_t *new_body, int x, int y, game_t *game):&#160;file.c']]],
  ['snakeclear_7',['snakeClear',['../file_8c.html#a575c4ef9821d4c0036d99be1a60a781d',1,'snakeClear(char **maze, game_t *game):&#160;file.c'],['../settings_8h.html#a575c4ef9821d4c0036d99be1a60a781d',1,'snakeClear(char **maze, game_t *game):&#160;file.c']]],
  ['snakeeatinghimself_8',['snakeEatingHimself',['../file_8c.html#af0d50429f59d6939fa83d9bd9788fa39',1,'snakeEatingHimself(game_t *game):&#160;file.c'],['../settings_8h.html#af0d50429f59d6939fa83d9bd9788fa39',1,'snakeEatingHimself(game_t *game):&#160;file.c']]],
  ['snakemovement_9',['snakeMovement',['../file_8c.html#afcb9a876225dcab40d6924169568fda4',1,'snakeMovement(int x, int y, game_t *game):&#160;file.c'],['../settings_8h.html#afcb9a876225dcab40d6924169568fda4',1,'snakeMovement(int x, int y, game_t *game):&#160;file.c']]],
  ['snakeprint_10',['snakePrint',['../file_8c.html#a33b5107357ca079bf2dc3cf4e805d212',1,'snakePrint(char **maze, game_t *game):&#160;file.c'],['../settings_8h.html#a33b5107357ca079bf2dc3cf4e805d212',1,'snakePrint(char **maze, game_t *game):&#160;file.c']]],
  ['snakeshrink_11',['snakeShrink',['../file_8c.html#a18a4ce64e63f3c74532908739d9973e3',1,'snakeShrink(game_t *game):&#160;file.c'],['../settings_8h.html#a18a4ce64e63f3c74532908739d9973e3',1,'snakeShrink(game_t *game):&#160;file.c']]],
  ['steps_12',['steps',['../structGame.html#a8ced659ba837811536c26ccd17ded578',1,'Game']]]
];
