var searchData=
[
  ['red_5fcrimson_0',['RED_CRIMSON',['../file_8c.html#a43d2f00e8028dd24854b0a4d7844ea91',1,'file.c']]],
  ['refresh_1',['refresh',['../file_8c.html#a5f2e190b8261a98c97c2ea4e86670d54',1,'refresh():&#160;file.c'],['../settings_8h.html#a5f2e190b8261a98c97c2ea4e86670d54',1,'refresh():&#160;file.c']]]
];
