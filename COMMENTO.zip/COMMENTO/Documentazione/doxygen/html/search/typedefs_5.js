var searchData=
[
  ['score_5ft_0',['score_t',['../settings_8h.html#a1aa2f17f03b90cd6716cc003eab4a93d',1,'settings.h']]]
];
