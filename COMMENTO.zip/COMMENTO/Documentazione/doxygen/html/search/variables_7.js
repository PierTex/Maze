var searchData=
[
  ['maze_5fsize_0',['maze_size',['../structGame.html#a57e8ed079a8339404208e48434671171',1,'Game']]],
  ['moves_1',['moves',['../structPath.html#a9b9ce3379439b175cbb8b88ab4a69c31',1,'Path']]]
];
