var searchData=
[
  ['head_0',['head',['../structGame.html#a5247050a1f72e586eb4b6d30257f5cce',1,'Game']]]
];
