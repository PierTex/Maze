var searchData=
[
  ['neighbors_0',['Neighbors',['../structNeighbors.html',1,'']]],
  ['node_1',['Node',['../structNode.html',1,'']]]
];
