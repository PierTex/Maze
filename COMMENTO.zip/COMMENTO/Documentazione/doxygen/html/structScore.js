var structScore =
[
    [ "best", "structScore.html#abcf246d1a7cfd156d8c9c1fa85433116", null ],
    [ "current", "structScore.html#a640ba9daa684f85b468296a1e76ee279", null ]
];