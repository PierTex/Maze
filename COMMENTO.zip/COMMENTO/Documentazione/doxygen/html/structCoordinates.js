var structCoordinates =
[
    [ "x", "structCoordinates.html#a11c878fbd2d0805c91af17d2ba2289a1", null ],
    [ "y", "structCoordinates.html#aae83211da8e94ae2edd3b407c19bff07", null ]
];