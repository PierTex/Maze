var structNode =
[
    [ "body", "structNode.html#aa4a9a7abf6362e3646d43814e69434f9", null ],
    [ "next", "structNode.html#af67b110ca1a258b793bf69d306929b22", null ]
];